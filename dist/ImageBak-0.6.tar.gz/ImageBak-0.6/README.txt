# ImageBak

Back up important directories on your computer

**This program is in development**

The interface works, but there are more UX features to come!

# Todo
- Progress Bar for zipping and unzipping
- Set `zip_safe = False`
- Add viewing of backups in restore interface

# Features
- Back up images to Bzip2 compressed zip files
- Restore these images on new/re-imaged computers
- UI Written in PyGTK3 and Glade XML (mostly)
