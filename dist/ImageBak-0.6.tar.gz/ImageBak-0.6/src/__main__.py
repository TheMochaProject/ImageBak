from Interface import MainView
def main():
    MainView.main()
if __name__=='__main__':
   main()
